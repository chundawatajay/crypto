<?php

return [
    'reached_pending_threshold' => 'You have pending transactions.',
    'canceled' => 'Payment was canceled.',
    'insufficient_balance' => 'Your balance is insufficient.',
    'unknown' => 'Unknown payment response.',
    'approved' => 'Payment was approved.',
    'gateway_description' => '(:gateway) :reference',
];
